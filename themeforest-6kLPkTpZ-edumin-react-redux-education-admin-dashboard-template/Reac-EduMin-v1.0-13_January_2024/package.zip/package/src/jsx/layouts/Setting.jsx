import React, { Fragment } from "react";




const Setting = () => {
 
  return (
	<>
		<Fragment>

		</Fragment>
		
	</>
  );
};

export default Setting;


