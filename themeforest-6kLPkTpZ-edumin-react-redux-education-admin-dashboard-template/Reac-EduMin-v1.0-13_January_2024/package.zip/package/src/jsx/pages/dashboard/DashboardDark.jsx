import React from 'react';





const DashboardDark = () => {
	// const { changeBackground } = useContext(ThemeContext);
	// useEffect(() => {
	// 	changeBackground({ value: "dark", label: "Dark" });
	// }, []);
	
	return(
		<>			
			<div className="row">
				
			</div>	
			
		</>		
		
	)
}
export default DashboardDark;